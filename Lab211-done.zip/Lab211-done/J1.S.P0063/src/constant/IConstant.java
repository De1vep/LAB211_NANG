package constant;

public interface IConstant {
    String REGEX_NAME = "^[a-zA-Z\\s]+";
    String REGEX_ADDRESS = "^[#.0-9a-zA-Z\\s,-]+$";
}
