package exception;

public class PhoneNumberMaxLengthException extends Exception {
    public PhoneNumberMaxLengthException(String message){
        super(message);
    }
}
